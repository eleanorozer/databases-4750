CREATE TABLE Employees(
   employee_id INTEGER  NOT NULL PRIMARY KEY 
  ,phone       INTEGER  NOT NULL
  ,age         INTEGER  NOT NULL
  ,salary      INTEGER  NOT NULL
);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (0,5046218927,39,44000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (1,8102929388,34,39000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (2,8566368749,36,41000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (3,9073854412,23,28000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (4,5135701893,28,33000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (5,4195032484,24,29000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (6,7735736914,33,38000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (7,4087523500,25,30000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (8,6054142147,25,30000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (9,4106558723,30,35000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (10,2158741229,38,43000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (11,6313353414,33,38000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (12,3104985651,22,27000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (13,4407808425,28,33000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (14,9565376195,25,30000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (15,6022774385,31,36000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (16,9313139635,30,35000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (17,4146619598,30,35000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (18,3132887937,26,31000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (19,8158282147,38,43000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (20,6105453615,28,33000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (21,4085401785,37,42000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (22,9723039197,21,26000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (23,5189667987,26,31000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (24,7326583154,26,31000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (25,7156626764,36,41000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (26,9133882079,21,26000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (27,4106691642,32,37000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (28,2125824976,27,32000);
INSERT INTO Employees(employee_id,phone,age,salary) VALUES (29,9363363951,35,40000);
